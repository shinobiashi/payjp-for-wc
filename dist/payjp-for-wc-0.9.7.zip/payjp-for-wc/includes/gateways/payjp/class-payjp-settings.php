<?php
/**
 * Shared settings manager for all PAY.JP payment gateways.
 *
 * @package Payjp_For_WooCommerce
 * @license GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Payjp_Settings' ) ) {
	return;
}

/**
 * Static accessors for shared PAY.JP settings stored in the `payjp_settings`
 * option. All gateways read from this single source of truth.
 *
 * Settings structure:
 * [
 *   'test_mode'       => bool,
 *   'test_public_key' => string,
 *   'test_secret_key' => string,
 *   'live_public_key' => string,
 *   'live_secret_key' => string,
 *   'webhook_secret'  => string,
 *   'enabled_methods' => string[], // e.g. ['card', 'paypay']
 *   'alert_email'     => string,
 * ]
 */
class Payjp_Settings {

	/**
	 * WordPress option key for all shared PAY.JP settings.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'payjp_settings';

	/**
	 * Get a single setting value.
	 *
	 * @param string $key      Setting key.
	 * @param mixed  $fallback Value returned when the key is absent.
	 * @return mixed
	 */
	public static function get( string $key, mixed $fallback = '' ): mixed {
		return self::get_all()[ $key ] ?? $fallback;
	}

	/**
	 * In-memory cache: avoids repeated get_option() calls within the same request.
	 * Invalidated by flush_cache() whenever the option is updated.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $cache = null;

	/**
	 * Get all settings as an associative array.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_all(): array {
		if ( null === self::$cache ) {
			$settings    = get_option( self::OPTION_KEY, array() );
			self::$cache = is_array( $settings ) ? $settings : array();
		}
		return self::$cache;
	}

	/**
	 * Invalidate the in-memory settings cache.
	 * Must be called after any update_option( self::OPTION_KEY, ... ) to ensure
	 * subsequent reads within the same request see the updated values.
	 */
	public static function flush_cache(): void {
		self::$cache = null;
	}

	/**
	 * Whether test mode is currently active.
	 */
	public static function is_test_mode(): bool {
		return (bool) self::get( 'test_mode', true );
	}

	/**
	 * Get the active public key (test or live), selected by mode.
	 */
	public static function get_public_key(): string {
		return self::is_test_mode()
			? (string) self::get( 'test_public_key' )
			: (string) self::get( 'live_public_key' );
	}

	/**
	 * Get the active secret key (test or live), selected by mode.
	 */
	public static function get_secret_key(): string {
		return self::is_test_mode()
			? (string) self::get( 'test_secret_key' )
			: (string) self::get( 'live_secret_key' );
	}

	/**
	 * Get the list of enabled payment method slugs.
	 *
	 * @return string[] e.g. ['card', 'paypay']
	 */
	public static function get_enabled_methods(): array {
		$settings = self::get_all();

		if ( array_key_exists( 'enabled_methods', $settings ) ) {
			return is_array( $settings['enabled_methods'] ) ? $settings['enabled_methods'] : array();
		}

		// When enabled_methods has never been saved, derive from the individual gateway
		// options so that an upgrade from a pre-unified-settings version preserves
		// which gateways were already enabled. On a genuine fresh install (no gateway
		// options exist yet) return [] — payment methods are opt-in, not opt-out.
		$derived         = array();
		$gateway_methods = array(
			'woocommerce_payjp_card_settings'   => 'card',
			'woocommerce_payjp_paypay_settings' => 'paypay',
		);
		foreach ( $gateway_methods as $option_key => $method ) {
			$gateway_settings = get_option( $option_key, null );
			if ( is_array( $gateway_settings ) && 'yes' === ( $gateway_settings['enabled'] ?? 'no' ) ) {
				$derived[] = $method;
			}
		}
		return $derived;
	}

	/**
	 * Whether a given payment method slug is enabled.
	 *
	 * @param string $method 'card' or 'paypay'.
	 */
	public static function is_method_enabled( string $method ): bool {
		return in_array( $method, self::get_enabled_methods(), true );
	}

	/**
	 * Get the Webhook verification token.
	 */
	public static function get_webhook_secret(): string {
		return (string) self::get( 'webhook_secret' );
	}

	/**
	 * Get the alert notification email address.
	 * Falls back to the site administrator email when unset or invalid.
	 */
	public static function get_alert_email(): string {
		$email = (string) self::get( 'alert_email' );
		if ( $email && is_email( $email ) ) {
			return $email;
		}
		return (string) get_option( 'admin_email' );
	}
}
